# Glowing Ore & Shadow

Satu pack, tiga subpack (pilih di Settings > Global Resources > ikon gear pack):

| Subpack | Isi |
|---|---|
| Shadow and Glowing Ore | shadow + ore glow (juga default root) |
| Glowing Ore Only | ore glow saja |
| Shadow Only | shadow saja |

Hanya material `RenderChunk` (vanilla shader + tambahan). Butuh MB Loader (Android) / Wyvern (Windows) / Hynis (iOS).

## Build
GitHub: Actions -> **build** -> Run workflow -> download artifact `.mcpack`.

Lokal: `pip install -r requirements.txt && ./build.sh setup && ./build.sh pack -p android -v 57`

## Struktur
- `src/newb/config.h` — switch subpack (`SHADOW_ONLY`, `GLOWING_ORE_ONLY`, `SHADOW_AND_GLOWING_ORE`), `NL_SHADOW_INTENSITY`, `NL_GLOW_TEX`
- `src/newb/functions/shadow.h`, `glow.h` — logika shadow & glow
- `src/materials/RenderChunk/` — vertex/fragment
- `src/newb/pack_config.toml` — nama, versi, daftar subpack
- `assets/textures/blocks/` — tekstur ore (alpha 252/255 = glow penuh, 253/255 = glow sebagian)

Credit: devendrn & Newb Shader contributors (MIT).
