$input a_color0, a_position, a_texcoord0, a_texcoord1
#ifdef INSTANCING
  $input i_data0, i_data1, i_data2, i_data3
#endif
$output v_color0, v_color1, v_fog, v_lightmapUV, v_texcoord0

#include <bgfx_shader.sh>
#include <newb/main.sh>

uniform vec4 RenderChunkFogAlpha;
uniform vec4 FogAndDistanceControl;
uniform vec4 ViewPositionAndTime;
uniform vec4 FogColor;
uniform vec4 TimeOfDay;

void main() {
  #ifdef INSTANCING
    mat4 model = mtxFromCols(i_data0, i_data1, i_data2, i_data3);
  #else
    mat4 model = u_model[0];
  #endif

  vec3 worldPos = mul(model, vec4(a_position, 1.0)).xyz;
  vec4 pos = mul(u_viewProj, vec4(worldPos, 1.0));

  #if !(defined(DEPTH_ONLY_OPAQUE) || defined(DEPTH_ONLY) || defined(INSTANCING))

  #ifdef RENDER_AS_BILLBOARDS
    vec4 color = vec4(1.0,1.0,1.0,1.0);
  #else
    vec4 color = a_color0;
  #endif

  // vanilla fog
  float camDis = length(ViewPositionAndTime.xyz - worldPos);
  float relativeDist = camDis / FogAndDistanceControl.z + RenderChunkFogAlpha.x;
  vec4 fog;
  fog.rgb = FogColor.rgb;
  fog.a = clamp((relativeDist - FogAndDistanceControl.x) / (FogAndDistanceControl.y - FogAndDistanceControl.x), 0.0, 1.0);

  vec2 uv0 = 2.0*a_texcoord0.xy;
  uv0 = fract(uv0) + ((floor(uv0)-0.5)/16384.0);
  vec2 uv1 = fract(a_texcoord1.y*vec2(256.0, 4096.0));

  #ifdef NL_SHADOW
    // shadow hanya di overworld (tidak di End / Nether / underwater)
    bool noShadow = nlDetectEnd(FogColor.rgb) || nlDetectNether(FogColor.rgb, FogAndDistanceControl.xy) || nlDetectUnderwater(FogColor.rgb, FogAndDistanceControl.xy);
    if (!noShadow) {
      color.rgb *= nlShadow(uv1, TimeOfDay.x);
    }
  #endif

  v_color0 = color;
  v_color1 = a_color0;
  v_fog = fog;
  v_texcoord0 = uv0;
  v_lightmapUV = uv1;

  #endif

  gl_Position = pos;
}
