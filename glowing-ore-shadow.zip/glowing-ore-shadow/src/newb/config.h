#ifndef NL_CONFIG_H
#define NL_CONFIG_H

/*
  Subpack switch. Tiap subpack di pack_config.toml mendefinisikan satu macro
  (UPPERCASE dari "define"). Root pack (build "default") = Shadow + Glowing Ore.

    SHADOW_AND_GLOWING_ORE -> shadow + glowing ore
    GLOWING_ORE_ONLY       -> glowing ore saja
    SHADOW_ONLY            -> shadow saja
*/
#if defined(GLOWING_ORE_ONLY)
  #define NL_GLOW
#elif defined(SHADOW_ONLY)
  #define NL_SHADOW
#else
  #define NL_SHADOW
  #define NL_GLOW
#endif

/* Shadow */
#define NL_SHADOW_INTENSITY 0.7   // 0.0 no shadow ~ 1.0 strong shadow

/* Ore glow intensity */
#define NL_GLOW_TEX 2.3           // 0.4 weak ~ 8.0 bright
//#define NL_GLOW_LEAK 0.6        // [toggle] 0.08 subtle ~ 1.0 100% brightness of NL_GLOW_TEX

/* Ore shimmer (glow berkedip) - hanya aktif di subpack yang punya glow */
#define NL_GLOW_SHIMMER 0.8       // [toggle] 0.1 subtle ~ 1.0 100% shimmer
#define NL_GLOW_SHIMMER_SPEED 0.9 // 0.5 slow ~ 2.0 fast

#ifndef NL_GLOW
  #undef NL_GLOW_SHIMMER
#endif

#endif
