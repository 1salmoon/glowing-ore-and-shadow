#ifndef SHADOW_H
#define SHADOW_H

// Deteksi End / Nether / underwater dari fog (sama seperti Newb detection.h).
// Di dimensi/kondisi ini shadow dimatikan.

bool nlDetectEnd(vec3 FOG_COLOR) {
  return FOG_COLOR.r==FOG_COLOR.b && (FOG_COLOR.r-FOG_COLOR.g>0.24 || (FOG_COLOR.g==0.0 && FOG_COLOR.r>0.1));
}

bool nlDetectNether(vec3 FOG_COLOR, vec2 FOG_CONTROL) {
  float expectedFogX = 0.029 + (0.09*FOG_CONTROL.y*FOG_CONTROL.y);
  bool netherFogCtrl = (FOG_CONTROL.x<0.14 && abs(FOG_CONTROL.x-expectedFogX) < 0.02);
  bool netherFogCol = (FOG_COLOR.r+FOG_COLOR.g)>0.0;
  // underlava dianggap nether
  bool underLava = FOG_CONTROL.x == 0.0 && FOG_COLOR.b == 0.0 && FOG_COLOR.g < 0.18 && FOG_COLOR.r-FOG_COLOR.g > 0.1;
  return (netherFogCtrl && netherFogCol) || underLava;
}

bool nlDetectUnderwater(vec3 FOG_COLOR, vec2 FOG_CONTROL) {
  return FOG_CONTROL.x==0.0 && FOG_CONTROL.y<0.8 && (FOG_COLOR.b>FOG_COLOR.r || FOG_COLOR.g>FOG_COLOR.r);
}

// Faktor terang sisi vertex (1.0 = tanpa bayangan). Dipakai: color.rgb *= nlShadow(...)
float nlShadow(vec2 uv1, float TIME_OF_DAY) {
  vec2 lit = uv1*uv1;
  float nightIntensity = 1.0 - (0.5 + 0.5*cos(6.283184*TIME_OF_DAY));
  nightIntensity *= nightIntensity;
  float shadowBase = 1.0 - NL_SHADOW_INTENSITY + (0.6*NL_SHADOW_INTENSITY*nightIntensity);
  float shadow = max(step(0.93, uv1.y), mix(shadowBase, 1.0, lit.y));
  return max(shadow, lit.x);
}

#endif
