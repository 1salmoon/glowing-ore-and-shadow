#ifndef NL_MAIN_H
#define NL_MAIN_H

#include "config.h"
#include "functions/shadow.h"
#include "functions/glow.h"

#endif
